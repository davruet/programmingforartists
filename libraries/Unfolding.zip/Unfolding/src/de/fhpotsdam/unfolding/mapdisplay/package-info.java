/**
 * Map displaying variations, for instance P2D or P3D.
 */
package de.fhpotsdam.unfolding.mapdisplay;
