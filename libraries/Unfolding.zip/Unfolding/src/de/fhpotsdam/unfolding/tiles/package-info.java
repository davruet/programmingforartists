/**
 * Handles map tiles loading from different sources. 
 * 
 * Slippy maps (such as Unfolding) consist of multiple tile images, containing small parts of the map area.
 */
package de.fhpotsdam.unfolding.tiles;
