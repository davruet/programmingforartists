/**
 * Provider can load tiles from different sources such as OpenStreetMaps,
 * Microsoft, Google, TileMill, etc (some of these are for informational purposes only).
 */

package de.fhpotsdam.unfolding.providers;
